'use strict'
module.exports = {
    NODE_ENV: '"production"',
    API_DOMAIN: '"http://www.royhsu.cn"',
    API_PORT: '"8088"'
}
